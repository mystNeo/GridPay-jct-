from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import random
import asyncio

from db import init_db, insert_transaction, get_all_transactions, update_status
from llm import explain_transaction

app = FastAPI(title="GRID-PAY API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

def run_simulation(meter_id=None):
    """Meter Telemetry Ingestion Bot -> Dynamic Tariff Calculation Agent -> Financial Settlement RPA"""
    if not meter_id:
        meter_id = f"M-{random.randint(1, 20)}"

    kwh = round(random.uniform(0.5, 6.0), 2)
    rate = 4.5
    amount = round(kwh * rate, 2)
    avg_baseline = 2.5
    is_anomaly = kwh > avg_baseline * 2

    explanation = explain_transaction(meter_id, kwh, rate, amount, is_anomaly)
    status = "PENDING_REVIEW" if is_anomaly else "SETTLED"

    insert_transaction(meter_id, kwh, rate, amount, status, explanation)

    return {
        "meter_id": meter_id,
        "kwh": kwh,
        "rate": rate,
        "amount": amount,
        "status": status,
        "explanation": explanation
    }

@app.get("/")
def root():
    return {"message": "GRID-PAY API is running"}

@app.post("/simulate")
def simulate_reading(meter_id: str = None):
    return run_simulation(meter_id)

@app.get("/transactions")
def transactions():
    rows = get_all_transactions()
    columns = ["id", "meter_id", "generation_kwh", "tariff_rate", "amount", "status", "ai_explanation"]
    return [dict(zip(columns, row)) for row in rows]

@app.get("/stats")
def stats():
    rows = get_all_transactions()
    total = len(rows)
    settled = sum(1 for r in rows if r[5] == "SETTLED")
    pending = sum(1 for r in rows if r[5] == "PENDING_REVIEW")
    rejected = sum(1 for r in rows if r[5] == "REJECTED")
    total_payout = sum(r[4] for r in rows)
    return {
        "total_transactions": total,
        "settled": settled,
        "pending_review": pending,
        "rejected": rejected,
        "total_payout": round(total_payout, 2)
    }

@app.post("/review/{transaction_id}")
def review_transaction(transaction_id: int, decision: str):
    """Human-in-the-Loop guardrail: approve or reject a flagged transaction"""
    new_status = "SETTLED" if decision == "approve" else "REJECTED"
    update_status(transaction_id, new_status)
    return {"id": transaction_id, "new_status": new_status}

# --- Auto-simulation loop so the system looks "live" during demo ---
@app.on_event("startup")
async def start_simulation_loop():
    asyncio.create_task(auto_simulate())

async def auto_simulate():
    while True:
        run_simulation()
        await asyncio.sleep(6)
