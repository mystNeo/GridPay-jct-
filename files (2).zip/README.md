# GRID-PAY — Setup & Run

## 1. Install dependencies
```
pip install -r requirements.txt
```

## 2. Set your Groq API key (get a free one at console.groq.com)

PowerShell:
```
$env:GROQ_API_KEY="your_key_here"
```

CMD:
```
set GROQ_API_KEY=your_key_here
```

Do this in EVERY new terminal window before running app.py.

## 3. Run the backend (Terminal 1)
```
uvicorn app:app --reload
```
- API: http://127.0.0.1:8000
- Interactive docs: http://127.0.0.1:8000/docs
- This auto-generates a new simulated transaction every 6 seconds.

## 4. Run the dashboard (Terminal 2, new window, same folder)
```
streamlit run dashboard.py
```
Opens at http://localhost:8501

## Files
- db.py         -> SQLite storage (transactions table)
- llm.py        -> Groq LLM call that explains each transaction / anomaly
- app.py        -> FastAPI backend: /simulate, /transactions, /stats, /review/{id}
- dashboard.py  -> Streamlit live dashboard with Approve/Reject buttons

## Demo flow
1. Start backend, then dashboard — transactions appear automatically.
2. When a row shows PENDING_REVIEW (anomaly detected), click Approve or Reject
   live on the dashboard — this is your Human-in-the-Loop safety guardrail.
3. Point to /docs to show the underlying agent API live if asked.
