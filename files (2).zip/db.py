import sqlite3

def init_db():
    conn = sqlite3.connect("grid.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meter_id TEXT,
            generation_kwh REAL,
            tariff_rate REAL,
            amount REAL,
            status TEXT,
            ai_explanation TEXT
        )
    """)
    conn.commit()
    conn.close()

def insert_transaction(meter_id, kwh, rate, amount, status, explanation):
    conn = sqlite3.connect("grid.db")
    c = conn.cursor()
    c.execute("""
        INSERT INTO transactions (meter_id, generation_kwh, tariff_rate, amount, status, ai_explanation)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (meter_id, kwh, rate, amount, status, explanation))
    conn.commit()
    conn.close()

def update_status(transaction_id, new_status):
    conn = sqlite3.connect("grid.db")
    c = conn.cursor()
    c.execute("UPDATE transactions SET status = ? WHERE id = ?", (new_status, transaction_id))
    conn.commit()
    conn.close()

def get_all_transactions():
    conn = sqlite3.connect("grid.db")
    c = conn.cursor()
    c.execute("SELECT * FROM transactions ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    return rows
