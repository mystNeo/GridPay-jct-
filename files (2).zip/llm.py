import os
from groq import Groq

# Reads the key from an environment variable named GROQ_API_KEY.
# Set it in your terminal BEFORE running any script that imports this file:
#   PowerShell:  $env:GROQ_API_KEY="your_key_here"
#   CMD:         set GROQ_API_KEY=your_key_here
# Never paste your real key directly into this file if you plan to share it.
client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

def explain_transaction(meter_id, kwh, rate, amount, is_anomaly):
    prompt = f"""
    Meter {meter_id} generated {kwh} kWh at a tariff rate of {rate}/kWh,
    resulting in a payout of {amount}.
    Anomaly flagged: {is_anomaly}.
    In 1-2 sentences, explain this transaction and, if anomalous, why it might be flagged.
    """
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=100
    )
    return response.choices[0].message.content
