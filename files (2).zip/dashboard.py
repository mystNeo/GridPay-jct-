import streamlit as st
import pandas as pd
import requests
import time

st.set_page_config(page_title="GRID-PAY Live Dashboard", layout="wide")
st.title("⚡ GRID-PAY — Live Agent Observability Dashboard")

API_URL = "http://127.0.0.1:8000"

placeholder = st.empty()

def load_data():
    try:
        r = requests.get(f"{API_URL}/transactions", timeout=5)
        return pd.DataFrame(r.json())
    except Exception:
        return pd.DataFrame()

while True:
    df = load_data()

    with placeholder.container():
        col1, col2, col3, col4 = st.columns(4)
        if not df.empty:
            col1.metric("Total Transactions", len(df))
            col2.metric("Total Payout (Rs)", f"{df['amount'].sum():.2f}")
            col3.metric("Pending Review", len(df[df["status"] == "PENDING_REVIEW"]))
            col4.metric("Settled", len(df[df["status"] == "SETTLED"]))
        else:
            col1.metric("Total Transactions", 0)

        st.subheader("Pending Review — Human-in-the-Loop")
        if not df.empty:
            pending = df[df["status"] == "PENDING_REVIEW"]
            if pending.empty:
                st.caption("No transactions currently need review.")
            for _, row in pending.iterrows():
                c1, c2, c3 = st.columns([4, 1, 1])
                c1.write(f"**{row['meter_id']}** — {row['generation_kwh']} kWh — Rs {row['amount']} — {row['ai_explanation']}")
                if c2.button("Approve", key=f"a{row['id']}"):
                    requests.post(f"{API_URL}/review/{row['id']}", params={"decision": "approve"})
                    st.rerun()
                if c3.button("Reject", key=f"r{row['id']}"):
                    requests.post(f"{API_URL}/review/{row['id']}", params={"decision": "reject"})
                    st.rerun()

        st.subheader("Transaction Log")
        if not df.empty:
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No transactions yet — waiting on backend...")

        st.subheader("Generation per Meter (kWh)")
        if not df.empty:
            st.bar_chart(df.set_index("meter_id")["generation_kwh"])

    time.sleep(3)
